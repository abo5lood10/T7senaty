@echo off
cd /d "%~dp0"
start "" "%~dp0T7senaty.exe" --session --launch
exit
